package business;

import javax.ejb.Local;
//This is used for Benchmark assignment

@Local
public interface SearchBusinessInterface {

	public String findVerse(String link);
}

