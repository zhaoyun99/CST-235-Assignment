package controllers;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Order;
import beans.User;

import business.OrdersBusinessInterface;

@ManagedBean
@ViewScoped
public class FormController {
	
	@Inject
	OrdersBusinessInterface service;
	
	
	//MyTimerService timer;
	
		
	public String onSubmit(User user)
	{
		// Call Business Service (for testing and demo CDI)
		//service.test();
		
		//Call Timer Service (for testing Programmatic Timer)
		//timer.setTimer(10000);
		
		//Call getAllOrders (for testing connection to DB)
		//getAllOrders();
		
		// Call insertOrder()
		//insertOrder();
		
		// See if the orders are properly inserted.
		//getAllOrders();
		
		// Forward to TestResponse.xhtml View along with the User Managed Bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		return "TestResponse.xhtml";
	}
	
	private void insertOrder()
	{
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		String sql = "INSERT INTO testapp.orders(order_no, product_name, price, quantity) VALUES('001122334455', 'This was inserted new', 25.00, 100)";
		
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.out.println("YOU FAILED!!!");
		}
	}
	
	private void getAllOrders()
	{
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		try {
			conn = DriverManager.getConnection(url, username, password);
			System.out.println("Success!!");
			conn.close();
		}
		catch(SQLException e)
		{
			System.out.println("FAILURE");
		}
		
		String sql = "SELECT * FROM testapp.orders";
		List<Order> orders = new ArrayList<Order>();
		
		try 
		{
			
			//Connect to the DB
			conn = DriverManager.getConnection(url, username, password);
			
			//Execute SQL Query
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			// Adding the database info through while loop
			/*
			 * while(rs.next()) { orders.add(new Order(rs.getString("order_no"),
			 * rs.getString("product_name"), rs.getFloat("price"), rs.getInt("quantity")));
			 * }
			 */
			
			while(rs.next())
			{
				System.out.println(String.format("ID is %d for Product %s at a price of %f", rs.getInt("id"), rs.getString("product_name"), rs.getFloat("price")));
			}
			
			
			//Cleanup
			rs.close();
		}
		
		catch (SQLException e)
		{
			e.printStackTrace();
			System.out.println("YOU FAILED!!!");
		}
		finally
		{
			//Cleanup
			if(conn != null)
			{
				try {
					conn.close();
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
		
		
	}
	
	public String onFlash(User user)
	{
		// Call Business Service (for testing and demo CDI)
		service.test();
				
		// Forward to TestResponse2.xhtml View along with User Managed Bean using Flashscope
		FacesContext.getCurrentInstance().getExternalContext().getFlash().put("user", user);
		return "TestResponse2.xhtml?faces-redirect=true";
	}
	
	public String onReturn()
	{
		// Return back to the JSF Login page or the TestForm page
		return "TestForm.xhtml";
	}
	
	public String onSendOrder()
	{
		Order order =  new Order();
		order.setOrderNumber("99");
		order.setPrice(99);
		order.setProductName("cheese");
		order.setQuantity(99);
		
		service.sendOrder(order);
		return "OrderResponse.xhtml";
	}
	
	public OrdersBusinessInterface getService()
	
		{ return service; }
	
	 
}
