package data;

import java.util.List;

import javax.ejb.Local;

import beans.Order;

@SuppressWarnings("hiding")
@Local

public interface DataAccessInterface <Order>{
	public List<Order> findAll(); 
	public Order findById(int id);
	public boolean create(Order order);
	public boolean update(Order order);
	public boolean delete(Order order);
}
