package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;
import data.OrdersDataService;

/**
 * Session Bean implementation class OrdersBusinessService
 */
@Alternative
@Stateless
@Local(OrdersBusinessInterface.class)

public class OrdersBusinessService implements OrdersBusinessInterface {

    @EJB
	OrdersDataService service;
    
	
	List<Order> orders = new ArrayList<Order>();
    
    
    public OrdersBusinessService() {
    	
    }
    
    public List<Order> getOrders()
    {
    	return service.findAll();
    }
    
    public void setOrders(List<Order> orders)
    {
    	// Do nothing now;
    }
    
    /**
     * @see OrdersBusinessInterface#test() 
     */
    public void test()
    {
    	// 4a and 4b
    	System.out.println("Hello from the OrdersBusinessService");
    }
    
    public OrdersDataService getService() {
    	return service;
    }

}
