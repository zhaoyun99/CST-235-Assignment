package data;

import beans.Order;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class OrdersDataService
 */
@Stateless
@Local(DataAccessInterface.class)
@LocalBean
public class OrdersDataService implements DataAccessInterface <Order> {

    /**
     * Default constructor. 
     */
    public OrdersDataService() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see DataAccessInterface#findAll()
     */
    
    public List<Order> findAll() 
    {
    	Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		try {
			conn = DriverManager.getConnection(url, username, password);
			System.out.println("Success!!");
			conn.close();
		}
		catch(SQLException e)
		{
			System.out.println("FAILURE");
		}
		
		String sql = "SELECT * FROM testapp.orders";
		List<Order> orders = new ArrayList<Order>();
		try 
		{
			
			//Connect to the DB
			conn = DriverManager.getConnection(url, username, password);
			
			//Execute SQL Query
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			// Adding the database info through while loop
			
			 while(rs.next()) 
			 { orders.add(new Order(rs.getInt("id"),
					 rs.getString("order_no"),
					 rs.getString("product_name"), 
					 rs.getFloat("price"), 
					 rs.getInt("quantity")));		
			}
			 
			//Cleanup
			rs.close();
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.out.println("YOU FAILED!!!");
		}
		finally
		{
			//Cleanup
			if(conn != null)
			{
				try {
					conn.close();
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
			 
		return orders;
    }

	@Override
	public Order findById(int id) {
		return null;
	}

	@Override
	public boolean create(Order order) {
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		//String sql = "INSERT INTO testapp.orders(order_no, product_name, price, quantity) VALUES('001122334455', 'This was inserted new', 25.00, 100)";
		String sql = String.format("INSERT INTO  testapp.orders(order_no, product_name, price, quantity) VALUES('%s', '%s', %f, %d)", order.getOrderNumber(), order.getProductName(), order.getPrice(), order.getQuantity());
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.out.println("YOU FAILED!!!");
		}
		finally
		{
			//Cleanup
			if(conn != null)
			{
				try {
					conn.close();
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
		return true;
	}

	@Override
	public boolean update(Order order) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean delete(Order order) {
		// TODO Auto-generated method stub
		return false;
	}

}
