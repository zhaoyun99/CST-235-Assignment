package business;


import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import beans.Order;
import data.DataAccessInterface;


@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface {

    @EJB  
	DataAccessInterface<Order> service;
    
    @Resource(mappedName="java:/ConnectionFactory")
	private ConnectionFactory connectionFactory;

	@Resource(mappedName="java:/jms/queue/Order")
	private Queue queue;
    
    
    
    public OrdersBusinessService() {
    	
    }
    
    public List<Order> getOrders()
    {
    	return service.findAll();
    }
    
    public void setOrders(List<Order> orders)
    {
    	// Do nothing now;
    }
    
    /**
     * @see OrdersBusinessInterface#test() 
     */
    public void test()
    {
    	// 4a and 4b
    	System.out.println("Hello from the OrdersBusinessService");
    }
    
    

    public void sendOrder(Order order)
    {
    	try 
		{
			Connection connection = connectionFactory.createConnection();
			Session  session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			MessageProducer messageProducer = session.createProducer(queue);
			
			TextMessage message1 = session.createTextMessage();
			message1.setText("This is test message");
			messageProducer.send(message1);
			
			ObjectMessage message2 = session.createObjectMessage();
			message2.setObject(order);
			messageProducer.send(message2);
			
			connection.close();
		} 
		catch (JMSException e) 
		{
			e.printStackTrace();
		}

    }
    
	/*
	 * public OrdersDataService getService() { return service; }
	 */

}
